~~~~
summary: Learn how to expose a GraphQL based read API with Spring Boot.
authors:
- sid: R576642
  name: Zubin Kavarana
  email: zubin.kavarana@jpmchase.com
- name: GLASS Architecture CIB
  email: glass_architecture_and_solutions@jpmchase.com  
publishDate: 2018/03/14
repoUrl: https://bitbucketdc.jpmchase.net/projects/TECHPRIMERS/repos/tech-primer-graphql/browse
tags: [java,graphql,api-design]
~~~~

# GraphQL API with Spring Boot Primer
[GraphQL](http://graphql.org/) is a query language for APIs, and a runtime for fulfilling those queries with your existing data.
GraphQL provides a type system that you use to define your data, and use that type system to allow clients to construct GraphQL queries.

* GraphQL is not tied down to any specific database or storage engine, and especially GraphQL does not need to have data stored in a graph Database!  
  
## Let's Illustrate
A GraphQL schema that describes `USER` with attributes `id` and `name` might look like:
~~~json
type Query {
  who: User
}

type User {
  id: String
  name: String
}
~~~
Assuming a GraphQL based web service exposing the schema above, you could `GET` the GraphQL query below:
~~~json
{
  who {
    name
  }
}
~~~
and the server will produce the JSON result returning only those requested fields (name):
~~~json
{
  "who": {
    "name": "Luke Skywalker"
  }
}
~~~
We cannot do justice to a full introduction and tutorial of GraphQL here. 
To find out more about GraphQL we recommend you take a tour through the links in the reference section at the end of this primer.

## GraphQL-Java
GraphQL was originally developed by Facebook and implemented in JavaScript, and is now being ported to other language implementations.
GraphQL-Java is the Java implementation of the GraphQL specification and based on the JavaScript reference implementation.
To serve GraphQL from your service layer, GraphQL-Java provides a set of constructs that you have to build in Java - 
- `Schema`: defines your GraphQL API by defining each field that can be queried or mutated
- `Object`: define an entity and its attributes
- `Interface`: you can also define an interface type with attributes, and from which multiple entities can extend
- `TypeResolver`: given a GraphQL-Java interface, returns the concrete type 
- `Scalar`: primitive type representations. You cna create your own scalars, like `DateTime` for example
- `DataFetcher`: this provides the glue between the data source and the GraphQL-Java type system. GraphQL-Java uses data fetcher on each object to fetch the data at execution time 

Here is an example of the GraphQL-Java DSL to build a GraphQL-Java Object definition (note the scalar fields)
~~~java
GraphQLObjectType starWarsCharacter = newObject()
                                        .name("StarWarsCharacter")
                                        .description("A character from the Star Wars epic")
                                        .field(newFieldDefinition()
                                                .name("id")
                                                .description("The id of the character in the database.")
                                                .type(GraphQLString))                                        
                                        .field(newFieldDefinition()
                                                .name("name")
                                                .description("The name of the character.")
                                                .type(GraphQLString))
                                        .field(newFieldDefinition()
                                                .name("isMainCharacter")
                                                .description("is this a main character?")
                                                .type(GraphQLBoolean))
                                        .build();
~~~

## What you'll build
[GraphQL.org](http://graphql.org/) uses the 'Star Wars Characters' graph model as the reference example. We will follow those footsteps in this tech primer and build the `Star Wars Character Information System` to help us illustrate the
 functionality and features of GraphQL.
 * The `Star Wars Character Information System` is a Spring Boot application written in Java
 * The Start Wars character data is pre-loaded and stored in the H2 database when the Microservice starts. Don't worry about the database used, you can use any SQL or NoSQL database as required by your modelling and usage constraints
 * The GraphQL API is exposed as a REST endpoint, against which you can `GET` data using a GraphQL query as a URL parameter  

## What you'll need
- About 45 minutes
- Favorite Java IDE
- JDK 1.8+
- Maven 3.2+
- Know how to use Spring Boot to make a microservice. If you need to get a hang of Spring Boot first, head over to the tech primer at [Spring Boot Primer - Part 1](https://tech-primers.gaiacloud.jpmchase.net/primers/tech-primer-spring-boot-part-1)

## 'In a Galaxy Far, Far Away....'
To illustrate the GraphQL API and the data it can return, we should first introduce the graph model and data model.
This is the the Star Wars Character graph schema and relational schema, which will give you an idea of the entities and attributes  - 

![star wars graph](images/starwars_schema.png)



## Lets Create a GraphQL API

### Getting Started
We recommend that you use the provided Spring Boot project provided in the `initial` folder, which comes with a Maven POM, basic application 
configuration and the JPA Entity model to boorstrap your development. 

To grab the starter code:
* Download primer code (left nav link) and unzip to a working directory
* `cd` to `initial`
* Import Maven project into your IDE or work from command line

### Let's start with a simple Spring Boot application
* Once you install the starter project you should find the following package structure and files
~~~
|   pom.xml
\---src
    \---main
    |    +---java
    |    |   \---com.jpmorganchase.techprimers.graphql
    |    |         \---domain.entity
    |    |               Character.java
    |    |               CharacterRepository.java
    |    |               Droid.java
    |    |               DroidRepository.java
    |    |               Episode.java
    |    |               EpisodeRepository.java
    |    |               Human.java
    |    |               HumanRepository.java
    |    |         \---web.controller
    |    |               GraphQLController.java     
    |    |         GraphQLMain.java    
    |    |
    |    +---resources
    |        application.yml
    |        bootstrap.yml
    |        \---dev\db\migration
    |              V1__Schema.sql
    |              V1.1__DataLoad.sql         
    |            
    \---test
        +---java
            \---com.jpmorganchase.techprimers.graphql
                    GraphQLWebTests.java
~~~
you should run the `test_00_Tests_that_our_Spring_Boot_service_starts_and_migrates_the_database` test 
in the `com.jpmorganchase.techprimers.graphql.GraphQLWebTests.java` test suite to check if the installation is okay so far.

### Important Concepts About This Project
Since we are boostrapping with a project that has already been built up to a certain extent, let's take a look at what we are building upon. 
* The Star Wars Character data is stored in an in-memory H2 database that is created on service startup.
* The data model in H2 is a relational model, matching the [ER diagram](https://en.wikipedia.org/wiki/Entity%E2%80%93relationship_model) above
* We use the DB Migrations library [Flyway](https://flywaydb.org/) to create tables and populate it with 
the Star Wars Characters data when Spring Boot starts
* JPA with Hibernate provides an ORM Entity layer and generate/connect to the database
* The `domain.entity` package contains the [JPA](https://spring.io/guides/gs/accessing-data-jpa/) entities and repositories.
These entities and [repositories](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories) are the objects that reflect the data ([DAO](https://en.wikipedia.org/wiki/Data_access_object)) an access patterns of the data
* The `web.controller` package contains the `GraphQLController` from where we will expose the query endpoint

### Adding GraphQL dependencies
Update the `pom.xml` file to add the GraphQL dependencies. 
- This will pull in the GraphQL dependency to be able to use the GraphQL-Java framework
~~~xml
<dependencies>
....
        <!-- GRAPHQL -->
        <dependency>
            <groupId>com.graphql-java</groupId>
            <artifactId>graphql-java</artifactId>
            <version>2.4.0</version>
        </dependency>
....
</dependencies>       
~~~
### A Service Layer
The first step is to add a service layer to our domain, that encapsulates the relational entity model.
- This protects the GraphQL Model from any changes to the Entity model and vice-versa
- Create package `com.jpmorganchase.techprimers.graphql.domain.service`
- Create the Interface `com\jpmorganchase\techprimers\graphql\domain\service\CharacterService.java` with the following content
~~~java
package com.jpmorgan.techprimers.graphql.domain.service;

import com.jpmorgan.techprimers.graphql.domain.entity.Character;
import com.jpmorgan.techprimers.graphql.domain.entity.Droid;
import com.jpmorgan.techprimers.graphql.domain.entity.Episode;
import com.jpmorgan.techprimers.graphql.domain.entity.Human;

import java.lang.*;
import java.util.List;

/**
 * Interface to the Star Wars Character domain
 */
public interface CharacterService {

    /**
     * Get a character by id. The character could be a droid or human
     * @param id The primary id of the character
     * @return Character
     */
    Character getCharacter(String id);

    /**
     * Get a droid by id.
     * @param id The primary id of the character
     * @return Droid
     */
    Droid getDroid(String id);

    /**
     * Get a human by id.
     * @param id The primary id of the character
     * @return Human
     */
    Human getHuman(String id);

    /**
     * Returns a list of Character that are friends of this Character
     * @param character Character for whom Friends are looked up
     * @return List of Characters
     */
    List<Character> getFriends(Character character);

    /**
     * Returns a list of Episodes that this Character appears in
     * @param character Character for whom Episodes are looked up
     * @return List of Episodes
     */
    List<Episode> getEpisodes(Character character);

}

~~~
- Create the implementing class `com\jpmorganchase\techprimers\graphql\domain\service\CharacterServiceImpl.java` with the following content
~~~java
package com.jpmorgan.techprimers.graphql.domain.service;

import com.jpmorgan.techprimers.graphql.domain.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.lang.*;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CharacterServiceImpl implements CharacterService {

    private final CharacterRepository characterRepository;
    private final DroidRepository droidRepository;
    private final HumanRepository humanRepository;

    @Autowired
    public CharacterServiceImpl(CharacterRepository characterRepository, DroidRepository droidRepository, HumanRepository humanRepository) {
        this.droidRepository = droidRepository;
        this.humanRepository = humanRepository;
        this.characterRepository = characterRepository;
    }

    @Override
    public Droid getDroid(String id) {
        return droidRepository.findOne(id);
    }

    @Override
    public Human getHuman(String id) {
        return humanRepository.findOne(id);
    }

    @Override
    public com.jpmorgan.techprimers.graphql.domain.entity.Character getCharacter(String id) {
        return characterRepository.findOne(id);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
    public List<com.jpmorgan.techprimers.graphql.domain.entity.Character> getFriends(com.jpmorgan.techprimers.graphql.domain.entity.Character character) {
        return getCharacter(character.getId()).getFriends();
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
    public List<Episode> getEpisodes(com.jpmorgan.techprimers.graphql.domain.entity.Character character) {
        return getCharacter(character.getId()).getAppearsIn().stream().collect(Collectors.toList());
    }
}
~~~
### Important Concepts
- All the methods in the interface are for fetching data only. This example does not consider insert or update as we are illustrating GraphQl for a data query API
- The data is connected to the database through JPA and Hibernate, and by using the [DDD](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories) Repositories pattern. The alternative concept in JPA is to use [ActiveRecord](https://en.wikipedia.org/wiki/Active_record_pattern) 
- There is some funky syntax over the `getEpisodes` and `getFriends` methods. Finding the `Friends` list in this example involves a self join over `Character`, and in JPA we have to instruct the framework to ignore transactional semantics over these methods

## The GraphQL Model Definition
We now turn to adding the GraphQL model which will use data sourced from the domain service layer (`CharacterService`) 
and provide a GraphQL schema object that can be queried with GraphQL queries.
1. The first step is to define the GraphQL types that can be queried and returned 
2. The types are then collected into a GraphQL `Query` object
3. The `Query` object is wrapped in a GraphQL `Schema`
4. The GraphQL `Schema` is the top level object from where GraphQL queries are processed

### Configuring the model
The model itself can be defined and instantiated in a number of ways. The method we chose was to define the
model in a Spring Boot Configuration class which will instantiate the model on startup.

- Create package `com.jpmorganchase.techprimers.graphql.model`
- Create `com\jpmorgan\techprimers\graphql\model\ModelConfiguration.java` with the following initial content

~~~java
package com.jpmorgan.techprimers.graphql.model;

import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.model.datafetcher.*;
import graphql.GraphQL;
import graphql.schema.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static graphql.Scalars.GraphQLString;
import static graphql.schema.GraphQLArgument.newArgument;
import static graphql.schema.GraphQLFieldDefinition.newFieldDefinition;
import static graphql.schema.GraphQLInterfaceType.newInterface;
import static graphql.schema.GraphQLList.list;
import static graphql.schema.GraphQLNonNull.nonNull;
import static graphql.schema.GraphQLObjectType.newObject;

@Configuration
public class ModelConfiguration {
    
}
~~~

#### Data Fetchers
Before we create the concrete object types in the GraphQl model, lets make sure we can fetch those entities from the tables. GraphQl does this through the `DataFetcher<T>` interface.

For example, the `EpisodeDataFetcher` will be invoked by GraphQL-Java when it needs to populate 'episode' objects in the model.
The data fetcher will use the environment variables to identify the episode identifier and allow you to query the data source.
- GraphQL-Java provides the data fetcher with the `DataFetchingEnvironment` object that contains execution details about the query being run and its arguments and parameters
- Here we lookup the `DataFetchingEnvironment` for the source object - the object in the schema one level above

To create the `EpisodeDataFetcher`
- Create package `com.jpmorganchase.techprimers.graphql.model.datafetcher`
- Create `com\jpmorgan\techprimers\graphql\model\datafetcher\EpisodeDataFetcher.java` with the following content. 
~~~java
package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.entity.Character;
import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.domain.entity.Episode;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

import java.util.List;

public class EpisodeDataFetcher implements DataFetcher<List<Episode>> {

    private final CharacterService characterService;

    public EpisodeDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    @Override
    public List<Episode> get(DataFetchingEnvironment environment) {
        Object sourceObject = environment.getSource();
        Character character = (Character) sourceObject;
        return characterService.getEpisodes(character);
    }
}

~~~
We also need to fetch 'humans' by id. Here we lookup the `DataFetchingEnvironment` for the 'id' argument to be provided by the client
- Create `com\jpmorgan\techprimers\graphql\model\datafetcher\HumanDataFetcher.java` with the following content
~~~java
package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.domain.entity.Human;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

public class HumanDataFetcher implements DataFetcher<Human> {

    private final CharacterService characterService;

    public HumanDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    @Override
    public Human get(DataFetchingEnvironment environment) {
        String id = environment.getArgument("id");
        return characterService.getHuman(id);
    }
}
~~~
- Create `com\jpmorgan\techprimers\graphql\model\datafetcher\DroidDataFetcher.java` with the following content
~~~java
package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.domain.entity.Droid;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

public class DroidDataFetcher implements DataFetcher<Droid> {

    private final CharacterService characterService;

    public DroidDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    @Override
    public Droid get(DataFetchingEnvironment environment) {
        String id = environment.getArgument("id");
        return characterService.getDroid(id);
    }

}
~~~
- Create `com\jpmorgan\techprimers\graphql\model\datafetcher\FriendsDataFetcher.java` with the following content
~~~java
package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.entity.Character;
import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

import java.util.List;

public class FriendsDataFetcher implements DataFetcher<List<Character>> {

    private final CharacterService characterService;

    public FriendsDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    @Override
    public List<Character> get(DataFetchingEnvironment environment) {
        Object sourceObject = environment.getSource();
        Character character = (Character) sourceObject;
        return characterService.getFriends(character);
    }
}
~~~
Finally, we want to find the hero of an episode. Here we lookup the `DataFetchingEnvironment` for the 'episode' argument to be provided by the client.
- Create `com\jpmorgan\techprimers\graphql\model\datafetcher\HeroDataFetcher.java` with the following content
~~~java
package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

public class HeroDataFetcher implements DataFetcher<Object> {

    private final CharacterService characterService;

    public HeroDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    /**
     * If the argument matches the 5th episode - The Empire Strikes Back - the Luke Skywalker is the hero, otherwise
     * R2D2 is the hero of the series
     * @param environment the DataFetchingEnvironment provided by GraphQL-Java at execution time
     * @return the Character object representing the hero of the given episode
     */
    @Override
    public Object get(DataFetchingEnvironment environment) {
        if (environment.containsArgument("episode") && environment.getArgument("episode") != null) {
            String episode = environment.getArgument("episode").toString();
            if (episode.equalsIgnoreCase("5")) {
                return characterService.getHuman("1000");
            }
        }
        return characterService.getDroid("2001");
    }
}
~~~
The last setp to setup the data fetchers is to declare them as beans - we can do that in the `ModelConfiguration.java` 
~~~java
...

@Configuration
public class ModelConfiguration {

    @Bean
    DroidDataFetcher droidDataFetcher(CharacterService characterService) {
        return new DroidDataFetcher(characterService);
    }

    @Bean
    FriendsDataFetcher friendsDataFetcher(CharacterService characterService) {
        return new FriendsDataFetcher(characterService);
    }

    @Bean
    EpisodeDataFetcher episodeDataFetcher(CharacterService characterService) {
        return new EpisodeDataFetcher(characterService);
    }

    @Bean
    HeroDataFetcher heroDataFetcher(CharacterService characterService) {
        return new HeroDataFetcher(characterService);
    }

    @Bean
    HumanDataFetcher humanDataFetcher(CharacterService characterService) {
        return new HumanDataFetcher(characterService);
    }

}
~~~
#### Building the model Objects
A quick look at the Graph model we drew above shows us some of the Objects and Interfaces.
- `Character`, an interface.
- `Human`, `Droid` and `Episode` are `Objects`. 
- `Human` and `Droid` extend `Character`.

First we should define the `Character` GraphQL Interface. Add the following @Bean to `ModelConfiguration.java`, and let's walk through the code below. 
- GraphQL-Java provides static helper methods to create it's data types. Thus `newInterface()` creates a `GraphQLInterfaceType` object, and `newObject()` creates a `GraphQLObjectType` object. 
- Use the `newInterface()` static builder method to build a new interface
- Each field defines an attribute of the interface
- Each field definition is added using the `newFieldDefinition()` and assigns a `name`, `description` and assigns a GraphQL `Scalar` or `Object` type
- A `GraphQLObjectType` field definition means that this interface or object contains another complex object type
- And finally, you can also define nested lists of types
~~~java
    @Bean(name = "characterInterface")
    GraphQLInterfaceType characterInterface(CharacterTypeResolver characterTypeResolver) {
        return newInterface()
                .name("Character")
                .description("A character in the Star Wars Trilogy")
                .field(newFieldDefinition()
                        .name("id")
                        .description("The id of the character.")
                        .type(nonNull(GraphQLString)))
                .field(newFieldDefinition()
                        .name("name")
                        .description("The name of the character.")
                        .type(GraphQLString))
                .field(newFieldDefinition()
                        .name("friends")
                        .description("The friends of the character, or an empty list if they have none.")
                        .type(list(new GraphQLTypeReference("Character"))))
                .field(newFieldDefinition()
                        .name("appearsIn")
                        .description("Which movies they appear in.")
                        .type(list(new GraphQLTypeReference("Episode"))))
                .typeResolver(characterTypeResolver)
                .build();
    }
~~~
Notice the `CharacterTypeResolver` argument which fails to compile. A `TypeResolver` is a class you provide that will
accept an interface instance and return the underlying concrete type.
- Create `com\jpmorgan\techprimers\graphql\model\datafetcher\CharacterTypeResolver.java` with the following content
~~~java
package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.entity.Character;
import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.domain.entity.Droid;
import com.jpmorgan.techprimers.graphql.domain.entity.Human;
import graphql.schema.GraphQLObjectType;
import graphql.schema.TypeResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class CharacterTypeResolver implements TypeResolver {

    @Autowired
    private ApplicationContext context;

    @Override
    public GraphQLObjectType getType(Object object) {
        if (object instanceof Droid) {
            return (GraphQLObjectType) context.getBean("droidType");
        } else if (object instanceof Human) {
            return (GraphQLObjectType) context.getBean("humanType");
        } else if (object instanceof String) {
            CharacterService characterService = (CharacterService) context.getBean("characterServiceImpl");
            Character character = characterService.getCharacter(object.toString());
            return getType(character);
        } else {
            return null;
        }
    }

} 
~~~

Next, create the concrete object types. We can illustrate this with the `Human` Object. Add the following @Bean to `ModelConfiguration.java`, and let's walk through the code below.
- The `Human` object implements the `Character` Interface
- Has `Friends` and `Episode` fields which are `Objects`
- Assigns `DataFetcher` objects to the Object fields. 
- The `DataFetcher` is the implementation that connects the GraphQL model to the underlying `Character Data Service`
~~~java
    @Bean(name = "humanType")
    GraphQLObjectType humanType(@Qualifier("characterInterface") GraphQLInterfaceType characterInterface,
                                @Qualifier("episodeType") GraphQLObjectType episodeType,
                                FriendsDataFetcher friendsDataFetcher,
                                EpisodeDataFetcher episodeDataFetcher) {
        return newObject()
                .name("Human")
                .description("A humanoid creature in the Star Wars universe.")
                .withInterface(characterInterface)
                .field(newFieldDefinition()
                        .name("id")
                        .description("The id of the human.")
                        .type(nonNull(GraphQLString)))
                .field(newFieldDefinition()
                        .name("name")
                        .description("The name of the human.")
                        .type(GraphQLString))
                .field(newFieldDefinition()
                        .name("friends")
                        .description("The friends of the human, or an empty list if they have none.")
                        .type(list(characterInterface))
                        .dataFetcher(friendsDataFetcher))
                .field(newFieldDefinition()
                        .name("appearsIn")
                        .description("Which movies they appear in.")
                        .type(list(episodeType))
                        .dataFetcher(episodeDataFetcher))
                .field(newFieldDefinition()
                        .name("homePlanet")
                        .description("The home planet of the human, or null if unknown.")
                        .type(GraphQLString))
                .build();
    }
~~~

Creating the remaining entity definitions as beans in the model is now straightforward.
-  Add the following @Bean definitions to `ModelConfiguration.java`
~~~java
    @Bean(name = "episodeType")
    GraphQLObjectType episodeType() {
        return newObject()
                .name("Episode")
                .description("A movie episode in the Star Wars universe.")
                .field(newFieldDefinition()
                        .name("id")
                        .description("The # of the episode.")
                        .type(nonNull(GraphQLString)))
                .field(newFieldDefinition()
                        .name("name")
                        .description("The name of the human.")
                        .type(GraphQLString))
                .field(newFieldDefinition()
                        .name("description")
                        .description("The description of the episode, or null if unknown.")
                        .type(GraphQLString))
                .build();
    }
    
    @Bean(name = "droidType")
    GraphQLObjectType droidType(@Qualifier("characterInterface") GraphQLInterfaceType characterInterface,
                                @Qualifier("episodeType") GraphQLObjectType episodeType,
                                FriendsDataFetcher friendsDataFetcher,
                                EpisodeDataFetcher episodeDataFetcher) {
        return newObject()
                .name("Droid")
                .description("A mechanical creature in the Star Wars universe.")
                .withInterface(characterInterface)
                .field(newFieldDefinition()
                        .name("id")
                        .description("The id of the droid.")
                        .type(nonNull(GraphQLString)))
                .field(newFieldDefinition()
                        .name("name")
                        .description("The name of the droid.")
                        .type(GraphQLString))
                .field(newFieldDefinition()
                        .name("friends")
                        .description("The friends of the droid, or an empty list if they have none.")
                        .type(list(characterInterface))
                        .dataFetcher(friendsDataFetcher))
                .field(newFieldDefinition()
                        .name("appearsIn")
                        .description("Which movies they appear in.")
                        .type(list(episodeType))
                        .dataFetcher(episodeDataFetcher))
                .field(newFieldDefinition()
                        .name("primaryFunction")
                        .description("The primary function of the droid.")
                        .type(GraphQLString))
                .build();
    }
~~~

Once we have the GraphQL objects defined, we can bring them together in `Query` objects. The `Query` is the building block for the GraphQL `Schema`.
- Add the following @Bean definitions to `ModelConfiguration.java`

~~~java
    @Bean(name = "queryType")
    GraphQLObjectType queryType(CharacterService characterService,
                                EpisodeDataFetcher episodeDataFetcher,
                                DroidDataFetcher droidDataFetcher,
                                HumanDataFetcher humanDataFetcher,
                                HeroDataFetcher heroDataFetcher,
                                @Qualifier("characterInterface") GraphQLInterfaceType characterInterface,
                                @Qualifier("episodeType") GraphQLObjectType episodeType,
                                @Qualifier("droidType") GraphQLObjectType droidType,
                                @Qualifier("humanType") GraphQLObjectType humanType) {
        return newObject()
                .name("QueryType")
                .field(newFieldDefinition()
                        .name("hero")
                        .type(characterInterface)
                        .argument(newArgument()
                                .name("episode")
                                .description("If omitted, returns the hero of the whole saga. If provided, returns the hero of that particular episode.")
                                .type(GraphQLString))
                        .dataFetcher(heroDataFetcher))
//                        .dataFetcher(new StaticDataFetcher(characterService.getDroid("2001"))))//hard coded value example
                .field(newFieldDefinition()
                        .name("human")
                        .type(humanType)
                        .argument(newArgument()
                                .name("id")
                                .description("id of the human")
                                .type(nonNull(GraphQLString)))
                        .dataFetcher(humanDataFetcher))
                .field(newFieldDefinition()
                        .name("droid")
                        .type(droidType)
                        .argument(newArgument()
                                .name("id")
                                .description("id of the droid")
                                .type(nonNull(GraphQLString)))
                        .dataFetcher(droidDataFetcher))
                .build();
    }

    @Bean(name = "starWarsSchema")
    GraphQLSchema starWarsSchema(@Qualifier("queryType") GraphQLObjectType queryType) {
        return GraphQLSchema.newSchema()
                .query(queryType)
                .build();
    }


    @Bean(name = "starWarsGraphQL")
    GraphQL swGraphQL(@Qualifier("starWarsSchema") GraphQLSchema starWarsSchema) {
        return GraphQL.newGraphQL(starWarsSchema).build();
    }
~~~


## Exposing the API
With a GraphQL `Schema` in place, we can now turn to the `GraphQLController.java` at `com.jpmorgan.techprimers.graphql.web.controller` and add in the GraphQL end point
from where the mode can be queried.
- Autowire the GraphQL `Schema` into the `com.jpmorgan.techprimers.graphql.web.controller.GraphQLController` controller
- Use the import statements from the code snippet below in the `GraphQLController.java`
~~~java
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmorgan.techprimers.graphql.domain.entity.DroidRepository;
import com.jpmorgan.techprimers.graphql.domain.entity.HumanRepository;
import graphql.ExecutionResult;
import graphql.GraphQL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class GraphQLController {

    @Autowired
    @Qualifier("starWarsGraphQL")
    private GraphQL starWarsGraphQL;
    
    ...
~~~
Add an end point method to serve `GET` requests at `/graphql`. Add the code content below to the `GraphQLController.java`
- The controller method expects a compulsory `Query` String, and an optional `Params` String
- the controller will pass the query and params to the GraphQl-Java `Schema`, and return the result as a `Map<K,V>`
- `asMap` converts JSON to a `Map<K,V>`
- `isEmpty` checks if the String is null or zero length
- `Map<K,V>` will be serialized to JSON by Spring Boot 
~~~java
    /**
     * @param query  the GraphQL query string
     * @param params the optional GraphQL query parameters
     * @return a Map of String key and Object value that will be converted to JSON
     * @throws Exception any Exception
     */
    @RequestMapping(method = RequestMethod.GET, headers = "Accept=application/json")
    public Map<String, Object> queryGraphModel(
            @RequestParam(name = "query") String query,
            @RequestParam(name = "params", required = false) String params) throws Exception {

        ExecutionResult executionResult = isEmpty(params) ? starWarsGraphQL.execute(query).getData() : starWarsGraphQL.execute(query, null, null, asMap(params)).getData();

        if (executionResult.getErrors().size() > 0) {
            Map<String, Object> errors = new HashMap<>();
            errors.put("code", "validation_error");
            final AtomicInteger count = new AtomicInteger();
            executionResult.getErrors().stream().forEach(error -> errors.put(count.incrementAndGet() + "# ", error.getMessage()));
            return errors;
        } else {
            Map<String, Object> result = executionResult.getData();
            if (result == null) {
                return asMap("{}");
            } else {
                return result;
            }
        }
    }
    
    /**
     * Checks if a String Object is null or empty
     *
     * @param someString any String
     * @return boolean true or false, whether the String is empty or not
     */
    private boolean isEmpty(String someString) {
        return (someString == null || someString.trim().length() == 0);
    }

    /**
     * De-serialize a JSON String into a Map
     *
     * @param someJSONString a JSON String
     * @return a Map containing key and values represented in JSON. Nested entries are further Maps
     * @throws Exception any Exception
     */
    private Map<String, Object> asMap(String someJSONString) throws Exception {
        return new ObjectMapper().readValue(someJSONString, new TypeReference<Map<String, String>>() {
        });
    }
~~~

We will also add an endpoint to fetch the Schema itself. This exposes the documentation of the schema to service clients.
- Add the code content below to the `GraphQLController.java`
~~~java
    @RequestMapping(value = "/api", method = RequestMethod.GET, headers = "Accept=application/json")
    public Map<String, Object> api() throws Exception {

        //this is a standard query published by the GraphQL project
        final String query = "  query IntrospectionQuery {\n    __schema {\n      queryType { name }\n      mutationType { name }\n      types {\n        ...FullType\n      }\n      directives {\n        name\n        description\n        args {\n          ...InputValue\n        }\n        onOperation\n        onFragment\n        onField\n      }\n    }\n  }\n\n  fragment FullType on __Type {\n    kind\n    name\n    description\n    fields {\n      name\n      description\n      args {\n        ...InputValue\n      }\n      type {\n        ...TypeRef\n      }\n      isDeprecated\n      deprecationReason\n    }\n    inputFields {\n      ...InputValue\n    }\n    interfaces {\n      ...TypeRef\n    }\n    enumValues {\n      name\n      description\n      isDeprecated\n      deprecationReason\n    }\n    possibleTypes {\n      ...TypeRef\n    }\n  }\n\n  fragment InputValue on __InputValue {\n    name\n    description\n    type { ...TypeRef }\n    defaultValue\n  }\n\n  fragment TypeRef on __Type {\n    kind\n    name\n    ofType {\n      kind\n      name\n      ofType {\n        kind\n        name\n        ofType {\n          kind\n          name\n        }\n      }\n    }\n  }\n";
        Map<String, Object> result = starWarsGraphQL.execute(query).getData();
        if (result == null) {
            return asMap("{}");
        } else {
            return result;
        }

    }
~~~

## Proof of the Pudding - Running the Tests
We can now run some tests with GraphQL queries and check if the results match the specification.
For example, we can test a query where we want to fetch the hero of the Star Wars saga (R2-D2) and fetch his id and name, and the names of all his friends. 
In GraphQL syntax the query is modelled as `{hero {id name friends{name}}}`
- Open the file `com.jpmorgan.techprimers.graphql.GraphQLWebTests.java`.
- Un-comment the test cases that have been commented out.
- Run the `test_02_Query_for_the_ID_and_friends_of_R2_D2` test, You should see the following output -
~~~commandline
{
    "hero": {
        "id": "2001",
        "name": "R2-D2",
        "friends": [
            {
                "name": "Luke Skywalker"
            },
            {
                "name": "Han Solo"
            },
            {
                "name": "Leia Organa"
            }
        ]
    }
}
~~~
- Run all the tests and you can go through them to understand inputs and outputs.

**Do download the code and look at all test queries for a grasp of the different things you can do with GraphQL.**

## Summary, and May The Force Be With You
Congratulations!

We hope you have enjoyed completing this primer. We've added some links below that we hope you find useful.

If you would like to contribute a primer to Tech Primers library,
please contact Tech_Primers@restricted.chase.com.

## References
* [Introduction to GraphQL](http://graphql.org/learn/)  
* [Facebook - Why GraphQL](https://code.facebook.com/posts/1691455094417024/graphql-a-data-query-language/)  
* [GraphQL for All? A Few Things to Think about before Blindly Dumping REST for GraphQL](https://www.infoq.com/presentations/api-rest-graphql)  

