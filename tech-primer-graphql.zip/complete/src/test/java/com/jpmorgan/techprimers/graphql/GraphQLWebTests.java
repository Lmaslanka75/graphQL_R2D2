package com.jpmorgan.techprimers.graphql;

import com.jayway.restassured.RestAssured;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.RestAssured.when;

/**
 * https://dev-blog.apollodata.com/the-anatomy-of-a-graphql-query-6dffa9e9e747
 */

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GraphQLWebTests {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Value("${local.server.port}")
    private int port;

    @Before
    public void setUp() {
        log.info("listening on port " + port);
        RestAssured.port = port;
    }

    /**
     * test the end point /graphql/dbcheck to get back how many droids and humans were populated in the database on
     * startup.
     */
    @Test
    public void test_00_Tests_that_our_Spring_Boot_service_starts_and_migrates_the_database() {
        when().
                get("/graphql/dbcheck").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("how_many_humans", Matchers.is(5)).
                body("how_many_droids", Matchers.is(2));
    }


    @Test
    public void test_01_Identifies_R2_D2_as_the_hero_of_the_Star_Wars_Saga() {
        //using short query syntax
        given().
                log().params().
                queryParam("query", "{hero{name}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("hero.name", Matchers.is("R2-D2"));

        //using full query syntax
        given().
                log().params().
                queryParam("query", "query HeroNameQuery {hero{name}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("hero.name", Matchers.is("R2-D2"));
    }

    @Test
    public void test_02_Query_for_the_ID_and_friends_of_R2_D2() {
        //using short query syntax
        given().
                queryParam("query", "{hero {id name friends{name}}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("hero.name", Matchers.is("R2-D2")).
                body("hero.id", Matchers.is("2001")).
                body("hero.friends.name", Matchers.hasItems("Luke Skywalker", "Han Solo" , "Leia Organa"));

        //using full query syntax
        given().
                queryParam("query", "query HeroNameAndFriendsQuery {hero {id name friends{name}}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("hero.name", Matchers.is("R2-D2")).
                body("hero.id", Matchers.is("2001")).
                body("hero.friends.name", Matchers.hasItems("Luke Skywalker", "Han Solo" , "Leia Organa"));
    }

    @Test
    public void test_03_Query_for_the_friends_of_friends_of_R2_D2() {
        //using short query syntax
        given().
                queryParam("query", "{hero {name friends {name appearsIn {name} friends {name}}}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("hero.name", Matchers.is("R2-D2")).
                body("hero.friends.name", Matchers.hasItems("Luke Skywalker", "Han Solo" , "Leia Organa")).
                body("hero.friends.appearsIn.name", Matchers.hasItems(Matchers.hasItems("EMPIRE", "NEWHOPE", "JEDI")));

        //using full query syntax
        given().
                queryParam("query", "query NestedQuery {hero {name friends {name appearsIn {name} friends {name}}}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("hero.name", Matchers.is("R2-D2")).
                body("hero.friends.name", Matchers.hasItems("Luke Skywalker", "Han Solo" , "Leia Organa")).
                body("hero.friends.appearsIn.name", Matchers.hasItems(Matchers.hasItems("EMPIRE", "NEWHOPE", "JEDI")));
    }

    @Test
    public void test_04_Query_for_Luke_Skywalker_directly_using_his_ID() {
        //using short query syntax
        given().
                queryParam("query", "{human(id: \"1000\") { name}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("human.name", Matchers.is("Luke Skywalker"));

        //using full query syntax
        given().
                queryParam("query", "query FetchLukeQuery {human(id: \"1000\") { name}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("human.name", Matchers.is("Luke Skywalker"));
    }

    @Test
    public void test_05a_Create_a_generic_query_then_use_it_to_fetch_Luke_Skywalker_using_his_ID() {
        //using full query syntax, short query syntax will not work with arguments
        given().
                queryParam("query", "query FetchSomeIDQuery($id: String!) {human(id: $id) {name}}").
                queryParam("params", "{\"id\": \"1000\"}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("human.name", Matchers.is("Luke Skywalker"));
    }

    @Test
    public void test_05b_Create_a_generic_query_then_pass_an_invalid_ID_to_get_null_back() {
        //using full query syntax, short query syntax will not work with arguments
        given().
                queryParam("query", "query HumanQuery($id: String!) {human(id: $id)  name}}").
                queryParam("params", "{\"id\": \"not a valid id\"}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("isEmpty()", Matchers.is(false)).
                body("code", Matchers.is("validation_error"));
    }

    @Test
    public void test_06_Query_for_both_Luke_and_Leia_using_two_root_fields_and_an_alias() {
        //using short query syntax
        given().
                queryParam("query", "{luke: human(id: \"1000\") {name} leia: human(id: \"1003\") {name}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("luke.name", Matchers.is("Luke Skywalker")).
                body("leia.name", Matchers.is("Leia Organa"));
    }

    @Test
    public void test_07_Query_for_Luke_changing_his_key_with_an_alias() {
        //using short query syntax
        given().
                queryParam("query", "{luke: human(id: \"1000\") {name}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("luke.name", Matchers.is("Luke Skywalker"));
    }

    @Test
    public void test_08_Query_using_duplicated_content() {
        //using short query syntax
        given().
                queryParam("query", "{luke: human(id: \"1000\") {name homePlanet} leia: human(id: \"1003\") {name homePlanet}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("luke.name", Matchers.is("Luke Skywalker")).
                body("luke.homePlanet", Matchers.is("Tatooine")).
                body("leia.name", Matchers.is("Leia Organa")).
                body("leia.homePlanet", Matchers.is("Alderaan"));
    }


    @Test
    public void test_09_Query_using_a_fragment_to_avoid_duplicating_content() {
        //using full query syntax, short query syntax will not work with fragments
        given().
                queryParam("query", "query UseFragment {luke: human(id: \"1000\") {...HumanFragment} leia: human(id: \"1003\") {...HumanFragment }} fragment HumanFragment on Human {name homePlanet}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("luke.name", Matchers.is("Luke Skywalker")).
                body("luke.homePlanet", Matchers.is("Tatooine")).
                body("leia.name", Matchers.is("Leia Organa")).
                body("leia.homePlanet", Matchers.is("Alderaan"));
    }

    @Test
    public void test_10_Verify_that_R2_D2_is_a_droid() {
        //using short query syntax
        given().
                queryParam("query", "{hero { __typename name}}").
        when().
                get("/graphql").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("hero.name", Matchers.is("R2-D2")).
                body("hero.__typename", Matchers.is("Droid"));
    }

    @Test
    public void test_11_Get_API() {
        when().
                get("/graphql/api").
        then().
                log().body().
                statusCode(HttpStatus.SC_OK);
    }

    @Test
    public void test_12_Identifies_Luke_as_the_hero_of_the_Empire_Strikes_Back_By_Using_Episode_As_Argument_Instead_of_ID() {
        //using full query syntax
        given().
                log().params().
                queryParam("query", "query HeroNameQuery {hero(episode: \"5\") {name}}").
                when().
                get("/graphql").
                then().
                log().body().
                statusCode(HttpStatus.SC_OK).
                body("hero.name", Matchers.is("Luke Skywalker"));
    }

}
