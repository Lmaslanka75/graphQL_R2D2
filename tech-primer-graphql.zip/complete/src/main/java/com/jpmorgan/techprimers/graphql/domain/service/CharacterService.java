package com.jpmorgan.techprimers.graphql.domain.service;

import com.jpmorgan.techprimers.graphql.domain.entity.Character;
import com.jpmorgan.techprimers.graphql.domain.entity.Droid;
import com.jpmorgan.techprimers.graphql.domain.entity.Episode;
import com.jpmorgan.techprimers.graphql.domain.entity.Human;

import java.lang.*;
import java.util.List;

/**
 * Interface to the Star Wars Character domain
 */
public interface CharacterService {

    /**
     * Get a character by id. The character could be a droid or human
     * @param id The primary id of the character
     * @return Character
     */
    Character getCharacter(String id);

    /**
     * Get a droid by id.
     * @param id The primary id of the character
     * @return Droid
     */
    Droid getDroid(String id);

    /**
     * Get a human by id.
     * @param id The primary id of the character
     * @return Human
     */
    Human getHuman(String id);

    /**
     * Returns a list of Character that are friends of this Character
     * @param character Character for whom Friends are looked up
     * @return List of Characters
     */
    List<Character> getFriends(Character character);

    /**
     * Returns a list of Episodes that this Character appears in
     * @param character Character for whom Episodes are looked up
     * @return List of Episodes
     */
    List<Episode> getEpisodes(Character character);

}
