package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.entity.Character;
import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

import java.util.List;

public class FriendsDataFetcher implements DataFetcher<List<Character>> {

    private final CharacterService characterService;

    public FriendsDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    @Override
    public List<Character> get(DataFetchingEnvironment environment) {
        Object sourceObject = environment.getSource();
        Character character = (Character) sourceObject;
        return characterService.getFriends(character);
    }
}
