package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.domain.entity.Droid;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

public class DroidDataFetcher implements DataFetcher<Droid> {

    private final CharacterService characterService;

    public DroidDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    @Override
    public Droid get(DataFetchingEnvironment environment) {
        String id = environment.getArgument("id");
        return characterService.getDroid(id);
    }

}
