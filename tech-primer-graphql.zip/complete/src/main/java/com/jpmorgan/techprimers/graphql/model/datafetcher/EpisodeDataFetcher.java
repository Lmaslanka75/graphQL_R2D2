package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.entity.Character;
import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.domain.entity.Episode;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

import java.util.List;

public class EpisodeDataFetcher implements DataFetcher<List<Episode>> {

    private final CharacterService characterService;

    public EpisodeDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    @Override
    public List<Episode> get(DataFetchingEnvironment environment) {
        Object sourceObject = environment.getSource();
        Character character = (Character) sourceObject;
        return characterService.getEpisodes(character);
    }
}
