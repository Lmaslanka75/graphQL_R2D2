package com.jpmorgan.techprimers.graphql.model;

import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.model.datafetcher.*;
import graphql.GraphQL;
import graphql.schema.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static graphql.Scalars.GraphQLString;
import static graphql.schema.GraphQLArgument.newArgument;
import static graphql.schema.GraphQLFieldDefinition.newFieldDefinition;
import static graphql.schema.GraphQLInterfaceType.newInterface;
import static graphql.schema.GraphQLList.list;
import static graphql.schema.GraphQLNonNull.nonNull;
import static graphql.schema.GraphQLObjectType.newObject;

@Configuration
public class ModelConfiguration {

    @Bean
    DroidDataFetcher droidDataFetcher(CharacterService characterService) {
        return new DroidDataFetcher(characterService);
    }

    @Bean
    FriendsDataFetcher friendsDataFetcher(CharacterService characterService) {
        return new FriendsDataFetcher(characterService);
    }

    @Bean
    EpisodeDataFetcher episodeDataFetcher(CharacterService characterService) {
        return new EpisodeDataFetcher(characterService);
    }

    @Bean
    HeroDataFetcher heroDataFetcher(CharacterService characterService) {
        return new HeroDataFetcher(characterService);
    }

    @Bean
    HumanDataFetcher humanDataFetcher(CharacterService characterService) {
        return new HumanDataFetcher(characterService);
    }

    @Bean(name = "characterInterface")
    GraphQLInterfaceType characterInterface(CharacterTypeResolver characterTypeResolver) {
        return newInterface()
                .name("Character")
                .description("A character in the Star Wars Trilogy")
                .field(newFieldDefinition()
                        .name("id")
                        .description("The id of the character.")
                        .type(nonNull(GraphQLString)))
                .field(newFieldDefinition()
                        .name("name")
                        .description("The name of the character.")
                        .type(GraphQLString))
                .field(newFieldDefinition()
                        .name("friends")
                        .description("The friends of the character, or an empty list if they have none.")
                        .type(list(new GraphQLTypeReference("Character"))))
                .field(newFieldDefinition()
                        .name("appearsIn")
                        .description("Which movies they appear in.")
                        .type(list(new GraphQLTypeReference("Episode"))))
                .typeResolver(characterTypeResolver)
                .build();
    }

    @Bean(name = "episodeType")
    GraphQLObjectType episodeType() {
        return newObject()
                .name("Episode")
                .description("A movie episode in the Star Wars universe.")
                .field(newFieldDefinition()
                        .name("id")
                        .description("The # of the episode.")
                        .type(nonNull(GraphQLString)))
                .field(newFieldDefinition()
                        .name("name")
                        .description("The name of the human.")
                        .type(GraphQLString))
                .field(newFieldDefinition()
                        .name("description")
                        .description("The description of the episode, or null if unknown.")
                        .type(GraphQLString))
                .build();
    }

    @Bean(name = "humanType")
    GraphQLObjectType humanType(@Qualifier("characterInterface") GraphQLInterfaceType characterInterface,
                                @Qualifier("episodeType") GraphQLObjectType episodeType,
                                FriendsDataFetcher friendsDataFetcher,
                                EpisodeDataFetcher episodeDataFetcher) {
        return newObject()
                .name("Human")
                .description("A humanoid creature in the Star Wars universe.")
                .withInterface(characterInterface)
                .field(newFieldDefinition()
                        .name("id")
                        .description("The id of the human.")
                        .type(nonNull(GraphQLString)))
                .field(newFieldDefinition()
                        .name("name")
                        .description("The name of the human.")
                        .type(GraphQLString))
                .field(newFieldDefinition()
                        .name("friends")
                        .description("The friends of the human, or an empty list if they have none.")
                        .type(list(characterInterface))
                        .dataFetcher(friendsDataFetcher))
                .field(newFieldDefinition()
                        .name("appearsIn")
                        .description("Which movies they appear in.")
                        .type(list(episodeType))
                        .dataFetcher(episodeDataFetcher))
                .field(newFieldDefinition()
                        .name("homePlanet")
                        .description("The home planet of the human, or null if unknown.")
                        .type(GraphQLString))
                .build();
    }

    @Bean(name = "droidType")
    GraphQLObjectType droidType(@Qualifier("characterInterface") GraphQLInterfaceType characterInterface,
                                @Qualifier("episodeType") GraphQLObjectType episodeType,
                                FriendsDataFetcher friendsDataFetcher,
                                EpisodeDataFetcher episodeDataFetcher) {
        return newObject()
                .name("Droid")
                .description("A mechanical creature in the Star Wars universe.")
                .withInterface(characterInterface)
                .field(newFieldDefinition()
                        .name("id")
                        .description("The id of the droid.")
                        .type(nonNull(GraphQLString)))
                .field(newFieldDefinition()
                        .name("name")
                        .description("The name of the droid.")
                        .type(GraphQLString))
                .field(newFieldDefinition()
                        .name("friends")
                        .description("The friends of the droid, or an empty list if they have none.")
                        .type(list(characterInterface))
                        .dataFetcher(friendsDataFetcher))
                .field(newFieldDefinition()
                        .name("appearsIn")
                        .description("Which movies they appear in.")
                        .type(list(episodeType))
                        .dataFetcher(episodeDataFetcher))
                .field(newFieldDefinition()
                        .name("primaryFunction")
                        .description("The primary function of the droid.")
                        .type(GraphQLString))
                .build();
    }

    @Bean(name = "queryType")
    GraphQLObjectType queryType(CharacterService characterService,
                                EpisodeDataFetcher episodeDataFetcher,
                                DroidDataFetcher droidDataFetcher,
                                HumanDataFetcher humanDataFetcher,
                                HeroDataFetcher heroDataFetcher,
                                @Qualifier("characterInterface") GraphQLInterfaceType characterInterface,
                                @Qualifier("episodeType") GraphQLObjectType episodeType,
                                @Qualifier("droidType") GraphQLObjectType droidType,
                                @Qualifier("humanType") GraphQLObjectType humanType) {
        return newObject()
                .name("QueryType")
                .field(newFieldDefinition()
                        .name("hero")
                        .type(characterInterface)
                        .argument(newArgument()
                                .name("episode")
                                .description("If omitted, returns the hero of the whole saga. If provided, returns the hero of that particular episode.")
                                .type(GraphQLString))
                        .dataFetcher(heroDataFetcher))
//                        .dataFetcher(new StaticDataFetcher(characterService.getDroid("2001"))))
                .field(newFieldDefinition()
                        .name("human")
                        .type(humanType)
                        .argument(newArgument()
                                .name("id")
                                .description("id of the human")
                                .type(nonNull(GraphQLString)))
                        .dataFetcher(humanDataFetcher))
                .field(newFieldDefinition()
                        .name("droid")
                        .type(droidType)
                        .argument(newArgument()
                                .name("id")
                                .description("id of the droid")
                                .type(nonNull(GraphQLString)))
                        .dataFetcher(droidDataFetcher))
                .build();
    }

    @Bean(name = "starWarsSchema")
    GraphQLSchema starWarsSchema(@Qualifier("queryType") GraphQLObjectType queryType) {
        return GraphQLSchema.newSchema()
                .query(queryType)
                .build();
    }


    @Bean(name = "starWarsGraphQL")
    GraphQL swGraphQL(@Qualifier("starWarsSchema") GraphQLSchema starWarsSchema) {
        return GraphQL.newGraphQL(starWarsSchema).build();
    }

}
