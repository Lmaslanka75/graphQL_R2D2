package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.entity.Character;
import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.domain.entity.Droid;
import com.jpmorgan.techprimers.graphql.domain.entity.Human;
import graphql.schema.GraphQLObjectType;
import graphql.schema.TypeResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class CharacterTypeResolver implements TypeResolver {

    @Autowired
    private ApplicationContext context;

    @Override
    public GraphQLObjectType getType(Object object) {
        if (object instanceof Droid) {
            return (GraphQLObjectType) context.getBean("droidType");
        } else if (object instanceof Human) {
            return (GraphQLObjectType) context.getBean("humanType");
        } else if (object instanceof String) {
            CharacterService characterService = (CharacterService) context.getBean("characterServiceImpl");
            Character character = characterService.getCharacter(object.toString());
            return getType(character);
        } else {
            return null;
        }
    }

}
