package com.jpmorgan.techprimers.graphql.domain.service;

import com.jpmorgan.techprimers.graphql.domain.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.lang.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 */
@Service
public class CharacterServiceImpl implements CharacterService {

    private final CharacterRepository characterRepository;
    private final DroidRepository droidRepository;
    private final HumanRepository humanRepository;

    @Autowired
    public CharacterServiceImpl(CharacterRepository characterRepository, DroidRepository droidRepository, HumanRepository humanRepository) {
        this.droidRepository = droidRepository;
        this.humanRepository = humanRepository;
        this.characterRepository = characterRepository;
    }

    @Override
    public Droid getDroid(String id) {
        return droidRepository.findOne(id);
    }

    @Override
    public Human getHuman(String id) {
        return humanRepository.findOne(id);
    }

    @Override
    public com.jpmorgan.techprimers.graphql.domain.entity.Character getCharacter(String id) {
        return characterRepository.findOne(id);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
    public List<com.jpmorgan.techprimers.graphql.domain.entity.Character> getFriends(com.jpmorgan.techprimers.graphql.domain.entity.Character character) {
        return getCharacter(character.getId()).getFriends();
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true, noRollbackFor = Exception.class)
    public List<Episode> getEpisodes(com.jpmorgan.techprimers.graphql.domain.entity.Character character) {
        return getCharacter(character.getId()).getAppearsIn().stream().collect(Collectors.toList());
    }
}
