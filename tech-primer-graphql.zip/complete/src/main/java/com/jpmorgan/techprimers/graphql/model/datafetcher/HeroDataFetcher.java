package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

public class HeroDataFetcher implements DataFetcher<Object> {

    private final CharacterService characterService;

    public HeroDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    /**
     * If the argument matches the 5th episode - The Empire Strikes Back - the Luke Skywalker is the hero, otherwise
     * R2D2 is the hero of the series
     * @param environment the DataFetchingEnvironment provided by GraphQL-Java at execution time
     * @return the Character object representing the hero of the given episode
     */
    @Override
    public Object get(DataFetchingEnvironment environment) {
        if (environment.containsArgument("episode") && environment.getArgument("episode") != null) {
            String episode = environment.getArgument("episode").toString();
            if (episode.equalsIgnoreCase("5")) {
                return characterService.getHuman("1000");
            }
        }
        return characterService.getDroid("2001");
    }
}
