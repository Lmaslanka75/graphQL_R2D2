package com.jpmorgan.techprimers.graphql.web.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmorgan.techprimers.graphql.domain.entity.DroidRepository;
import com.jpmorgan.techprimers.graphql.domain.entity.HumanRepository;
import graphql.ExecutionResult;
import graphql.GraphQL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Controller that will serve requests at the /graphql route
 */
@RequestMapping("/graphql")
@RestController
public class GraphQLController {

    @Autowired
    @Qualifier("starWarsGraphQL")
    private GraphQL starWarsGraphQL;

    @Autowired
    HumanRepository humanRepository;

    @Autowired
    DroidRepository droidRepository;

    /**
     * Returns a representation of a complex type with number of humans and number of droids in the data store.
     *
     * @return Map of key and values
     * @throws Exception
     */
    @RequestMapping(value = "/dbcheck", method = RequestMethod.GET, headers = "Accept=application/json")
    public Map<String, Integer> dbcheck() throws Exception {
        Map<String, Integer> characterCounts = new HashMap<>();
        characterCounts.put("how_many_humans", humanRepository.getHumanIds().size());
        characterCounts.put("how_many_droids", droidRepository.getDroidIds().size());
        return characterCounts;
    }

    /**
     * @param query  the GraphQL query string
     * @param params the optional GraphQL query parameters
     * @return a Map of String key and Object value that will be converted to JSON
     * @throws Exception any Exception
     */
    @RequestMapping(method = RequestMethod.GET, headers = "Accept=application/json")
    public Map<String, Object> queryGraphModel(
            @RequestParam(name = "query") String query,
            @RequestParam(name = "params", required = false) String params) throws Exception {

        ExecutionResult executionResult = isEmpty(params) ? starWarsGraphQL.execute(query) : starWarsGraphQL.execute(query, null, null, asMap(params));

        if (executionResult.getErrors().size() > 0) {
            Map<String, Object> errors = new HashMap<>();
            errors.put("code", "validation_error");
            final AtomicInteger count = new AtomicInteger();
            executionResult.getErrors().stream().forEach(error -> errors.put(count.incrementAndGet() + "# ", error.getMessage()));
            return errors;
        } else {
            Map<String, Object> result = executionResult.getData();
            if (result == null) {
                return asMap("{}");
            } else {
                return result;
            }
        }
    }

    @RequestMapping(value = "/api", method = RequestMethod.GET, headers = "Accept=application/json")
    public Map<String, Object> api() throws Exception {

        final String query = "  query IntrospectionQuery {\n    __schema {\n      queryType { name }\n      mutationType { name }\n      types {\n        ...FullType\n      }\n      directives {\n        name\n        description\n        args {\n          ...InputValue\n        }\n        onOperation\n        onFragment\n        onField\n      }\n    }\n  }\n\n  fragment FullType on __Type {\n    kind\n    name\n    description\n    fields {\n      name\n      description\n      args {\n        ...InputValue\n      }\n      type {\n        ...TypeRef\n      }\n      isDeprecated\n      deprecationReason\n    }\n    inputFields {\n      ...InputValue\n    }\n    interfaces {\n      ...TypeRef\n    }\n    enumValues {\n      name\n      description\n      isDeprecated\n      deprecationReason\n    }\n    possibleTypes {\n      ...TypeRef\n    }\n  }\n\n  fragment InputValue on __InputValue {\n    name\n    description\n    type { ...TypeRef }\n    defaultValue\n  }\n\n  fragment TypeRef on __Type {\n    kind\n    name\n    ofType {\n      kind\n      name\n      ofType {\n        kind\n        name\n        ofType {\n          kind\n          name\n        }\n      }\n    }\n  }\n";
        Map<String, Object> result = starWarsGraphQL.execute(query).getData();
        if (result == null) {
            return asMap("{}");
        } else {
            return result;
        }

    }

    /**
     * Checks if a String Object is null or empty
     *
     * @param someString any String
     * @return boolean true or false, whether the String is empty or not
     */
    private boolean isEmpty(String someString) {
        return (someString == null || someString.trim().length() == 0);
    }

    /**
     * De-serialize a JSON String into a Map
     *
     * @param someJSONString a JSON String
     * @return a Map containing key and values represented in JSON. Nested entries are further Maps
     * @throws Exception any Exception
     */
    private Map<String, Object> asMap(String someJSONString) throws Exception {
        return new ObjectMapper().readValue(someJSONString, new TypeReference<Map<String, String>>() {
        });
    }

}
