package com.jpmorgan.techprimers.graphql.model.datafetcher;

import com.jpmorgan.techprimers.graphql.domain.service.CharacterService;
import com.jpmorgan.techprimers.graphql.domain.entity.Human;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;

public class HumanDataFetcher implements DataFetcher<Human> {

    private final CharacterService characterService;

    public HumanDataFetcher(CharacterService characterService) {
        this.characterService = characterService;
    }

    @Override
    public Human get(DataFetchingEnvironment environment) {
        String id = environment.getArgument("id");
        return characterService.getHuman(id);
    }
}
