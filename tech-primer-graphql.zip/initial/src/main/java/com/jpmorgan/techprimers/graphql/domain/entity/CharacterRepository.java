package com.jpmorgan.techprimers.graphql.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * JPA Repository for the Character entity.
 */
@Repository
public interface CharacterRepository extends JpaRepository<Character, String>, JpaSpecificationExecutor<Character> {

}
