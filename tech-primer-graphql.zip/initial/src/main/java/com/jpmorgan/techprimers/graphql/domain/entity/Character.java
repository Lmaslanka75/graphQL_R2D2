package com.jpmorgan.techprimers.graphql.domain.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Character abstract entity
 */
@Entity
public abstract class Character {

    @Id
    @Column(name = "id")
    private String id;

    @Version
    @Column(name = "version")
    private Integer version;

    @NotNull
    private String name;

    // many to many on same table
    @ManyToMany
    @JoinTable(name = "tbl_friends",
            joinColumns = @JoinColumn(name = "personId"),
            inverseJoinColumns = @JoinColumn(name = "friendId")
    )
    private List<Character> friends;

    // many to many on same table
    @ManyToMany
    @JoinTable(name = "tbl_friends",
            joinColumns = @JoinColumn(name = "friendId"),
            inverseJoinColumns = @JoinColumn(name = "personId")
    )
    private List<Character> friendOf;

    @ManyToMany(cascade = CascadeType.MERGE)
    private Set<Episode> appearsIn = new HashSet<>();

    public Character() {

    }

    public Character(String id, String name, List<Episode> appearsIn) {
        this.id = id;
        this.name = name;
        this.appearsIn = new HashSet<>();
        this.appearsIn.addAll(appearsIn);
    }

    public Character(String id, String name, List<Character> friends, List<Episode> appearsIn) {
        this.id = id;
        this.name = name;
        this.friends = friends;
        this.appearsIn = new HashSet<>();
        this.appearsIn.addAll(appearsIn);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Character> getFriends() {
        return friends;
    }

    public void setFriends(List<Character> friends) {
        this.friends = friends;
    }

    public List<Character> getFriendOf() {
        return friendOf;
    }

    public void setFriendOf(List<Character> friendOf) {
        this.friendOf = friendOf;
    }

    public Set<Episode> getAppearsIn() {
        return appearsIn;
    }

    public void setAppearsIn(Set<Episode> appearsIn) {
        this.appearsIn = appearsIn;
    }
}
