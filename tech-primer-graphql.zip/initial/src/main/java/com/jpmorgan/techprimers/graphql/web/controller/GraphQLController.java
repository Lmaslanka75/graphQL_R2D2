package com.jpmorgan.techprimers.graphql.web.controller;

import com.jpmorgan.techprimers.graphql.domain.entity.DroidRepository;
import com.jpmorgan.techprimers.graphql.domain.entity.HumanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Controller that will serve requests at the /graphql route
 */
@RequestMapping("/graphql")
@RestController
public class GraphQLController {

    @Autowired
    HumanRepository humanRepository;

    @Autowired
    DroidRepository droidRepository;

    /**
     * Returns a representation of a complex type with number of humans and number of droids in the data store.
     * @return Map of key and values
     * @throws Exception
     */
    @RequestMapping(value = "/dbcheck", method = RequestMethod.GET, headers = "Accept=application/json")
    public Map<String, Integer> dbcheck() throws Exception {
        Map<String, Integer> characterCounts = new HashMap<>();
        characterCounts.put("how_many_humans", humanRepository.getHumanIds().size());
        characterCounts.put("how_many_droids", droidRepository.getDroidIds().size());
        return characterCounts;
    }

}
