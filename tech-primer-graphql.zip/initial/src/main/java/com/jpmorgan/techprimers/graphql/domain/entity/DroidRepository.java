package com.jpmorgan.techprimers.graphql.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * JPA Repository for the Droid entity.
 */
@Repository
public interface DroidRepository extends JpaRepository<Droid, String>, JpaSpecificationExecutor<Droid> {

    @Query("SELECT d.id FROM Droid d")
    List<String> getDroidIds();

}
