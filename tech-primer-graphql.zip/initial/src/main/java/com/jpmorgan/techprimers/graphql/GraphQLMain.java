package com.jpmorgan.techprimers.graphql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot Application Main class, which is run to start up the GraphQL microservice
 */
@SpringBootApplication
@EnableAutoConfiguration
public class GraphQLMain {

    public static void main(String[] args) {
        SpringApplication.run(GraphQLMain.class, args);
    }

}
