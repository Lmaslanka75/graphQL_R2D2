package com.jpmorgan.techprimers.graphql.domain.entity;

import javax.persistence.Entity;
import java.util.List;

/**
 * Human entity
 */
@Entity
public class Human extends Character {

    private String homePlanet;

    public Human() {
        super();
    }

    public Human(String id, String name, List<Episode> appearsIn, String homePlanet) {
        super(id, name, appearsIn);
        this.homePlanet = homePlanet;
    }

    public Human(String id, String name, List<Character> friends, List<Episode> appearsIn, String homePlanet) {
        super(id, name, friends, appearsIn);
        this.homePlanet = homePlanet;
    }

    public String getHomePlanet() {
        return homePlanet;
    }

    public void setHomePlanet(String homePlanet) {
        this.homePlanet = homePlanet;
    }

}
