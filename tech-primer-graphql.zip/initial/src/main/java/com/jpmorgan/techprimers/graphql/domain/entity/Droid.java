package com.jpmorgan.techprimers.graphql.domain.entity;

import javax.persistence.Entity;
import java.util.List;

/**
 * Droid entity
 */
@Entity
public class Droid extends Character {

    private String primaryFunction;

    public Droid() {
        super();
    }

    public Droid(String id, String name, List<Episode> appearsIn, String primaryFunction) {
        super(id, name, appearsIn);
        this.primaryFunction = primaryFunction;
    }

    public Droid(String id, String name, List<Character> friends, List<Episode> appearsIn, String primaryFunction) {
        super(id, name, friends, appearsIn);
        this.primaryFunction = primaryFunction;
    }

    public String getPrimaryFunction() {
        return primaryFunction;
    }

    public void setPrimaryFunction(String primaryFunction) {
        this.primaryFunction = primaryFunction;
    }

}
