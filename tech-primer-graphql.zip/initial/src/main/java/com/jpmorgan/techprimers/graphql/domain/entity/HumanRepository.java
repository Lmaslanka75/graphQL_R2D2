package com.jpmorgan.techprimers.graphql.domain.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * JPA Repository for the Human entity.
 */
@Repository
public interface HumanRepository extends JpaRepository<Human, String>, JpaSpecificationExecutor<Human> {

    @Query("SELECT h.id FROM Human h")
    List<String> getHumanIds();

}
