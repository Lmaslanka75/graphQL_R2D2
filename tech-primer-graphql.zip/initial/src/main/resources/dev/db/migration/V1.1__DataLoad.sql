-- episodes
insert into episode (description, name, version, id) values ('Released in 1977.', 'NEWHOPE', 0, 4);
insert into episode (description, name, version, id) values ('Released in 1980.', 'EMPIRE', 0, 5);
insert into episode (description, name, version, id) values ('Released in 1983.', 'JEDI', 0, 6);

-- droids
insert into character (name, version, primary_function, dtype, id) values ('C-3PO', 0, 'Protocol', 'Droid', '2000');
insert into character (name, version, primary_function, dtype, id) values ('R2-D2', 0, 'Astromech', 'Droid', '2001');
insert into character_appears_in (character_id, appears_in_id) values ('2000', 4);
insert into character_appears_in (character_id, appears_in_id) values ('2000', 5);
insert into character_appears_in (character_id, appears_in_id) values ('2000', 6);
insert into character_appears_in (character_id, appears_in_id) values ('2001', 4);
insert into character_appears_in (character_id, appears_in_id) values ('2001', 5);
insert into character_appears_in (character_id, appears_in_id) values ('2001', 6);

-- humans
insert into character (name, version, home_planet, dtype, id) values ('Luke Skywalker', 0, 'Tatooine', 'Human', '1000');
insert into character (name, version, home_planet, dtype, id) values ('Darth Vader', 0, 'Tatooine', 'Human', '1001');
insert into character (name, version, home_planet, dtype, id) values ('Han Solo', 0, null, 'Human', '1002');
insert into character (name, version, home_planet, dtype, id) values ('Leia Organa', 0, 'Alderaan', 'Human', '1003');
insert into character (name, version, home_planet, dtype, id) values ('Wilhuff Tarkin', 0, null, 'Human', '1004');
insert into character_appears_in (character_id, appears_in_id) values ('1000', 4);
insert into character_appears_in (character_id, appears_in_id) values ('1000', 5);
insert into character_appears_in (character_id, appears_in_id) values ('1000', 6);
insert into character_appears_in (character_id, appears_in_id) values ('1001', 4);
insert into character_appears_in (character_id, appears_in_id) values ('1001', 5);
insert into character_appears_in (character_id, appears_in_id) values ('1001', 6);
insert into character_appears_in (character_id, appears_in_id) values ('1002', 4);
insert into character_appears_in (character_id, appears_in_id) values ('1002', 5);
insert into character_appears_in (character_id, appears_in_id) values ('1002', 6);
insert into character_appears_in (character_id, appears_in_id) values ('1003', 4);
insert into character_appears_in (character_id, appears_in_id) values ('1003', 5);
insert into character_appears_in (character_id, appears_in_id) values ('1003', 6);
insert into character_appears_in (character_id, appears_in_id) values ('1004', 4);

-- update friends
insert into tbl_friends (person_id, friend_id) values ('2000', '1000');
insert into tbl_friends (person_id, friend_id) values ('2000', '1002');
insert into tbl_friends (person_id, friend_id) values ('2000', '1003');
insert into tbl_friends (person_id, friend_id) values ('2000', '2001');
insert into tbl_friends (person_id, friend_id) values ('2001', '1000');
insert into tbl_friends (person_id, friend_id) values ('2001', '1002');
insert into tbl_friends (person_id, friend_id) values ('2001', '1003');
insert into tbl_friends (person_id, friend_id) values ('1000', '1002');
insert into tbl_friends (person_id, friend_id) values ('1000', '1003');
insert into tbl_friends (person_id, friend_id) values ('1000', '2000');
insert into tbl_friends (person_id, friend_id) values ('1000', '2001');
insert into tbl_friends (person_id, friend_id) values ('1001', '1004');
insert into tbl_friends (person_id, friend_id) values ('1002', '1000');
insert into tbl_friends (person_id, friend_id) values ('1002', '1003');
insert into tbl_friends (person_id, friend_id) values ('1002', '2001');
insert into tbl_friends (person_id, friend_id) values ('1003', '1000');
insert into tbl_friends (person_id, friend_id) values ('1003', '1002');
insert into tbl_friends (person_id, friend_id) values ('1003', '2001');
insert into tbl_friends (person_id, friend_id) values ('1004', '1001');

