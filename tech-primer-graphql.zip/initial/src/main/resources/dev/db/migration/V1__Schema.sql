create table character (dtype varchar(31) not null, id varchar(255) not null, name varchar(255) not null, version integer, primary_function varchar(255), home_planet varchar(255), primary key (id));
create table character_appears_in (character_id varchar(255) not null, appears_in_id integer not null, primary key (character_id, appears_in_id));
create table episode (id integer not null, description varchar(255) not null, name varchar(255) not null, version integer, primary key (id));
create table tbl_friends (person_id varchar(255) not null, friend_id varchar(255) not null);
alter table character_appears_in add constraint FK8ndfr0dmk4pugjpbr952ks4h6 foreign key (appears_in_id) references episode;
alter table character_appears_in add constraint FKrowtn4j0o2qr2g9sjyohppx1e foreign key (character_id) references character;
alter table tbl_friends add constraint FKc7ri21sdqvywwggka9l7gm8yj foreign key (friend_id) references character;
alter table tbl_friends add constraint FKmg80t1jujjj4roeb5gvg5gxqv foreign key (person_id) references character;